﻿namespace RemoteControl.Network
{
    public class MessageHeader
    {
        public MessageType Type { get; set; }
        public int DataLength { get; set; }
        public string? FileName { get; set; }
    }
}
