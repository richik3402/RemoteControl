﻿namespace RemoteControl.Network
{
    public enum CommandType
    {
        Shutdown,
        Restart,
        ClipboardRequest,
        Screenshot,
        StartStream,
        StopStream,
        SetStreamSettings,
        SetClientSettings
    }
}
