﻿namespace RemoteControl.Network
{
    public class CommandMessage
    {
        public CommandType Command { get; set; }
        public int Resolution { get; set; }
        public int Quality { get; set; }
        public int FPS { get; set; }
        public bool AllowMouse { get; set; } = true;
        public bool AllowKeyboard { get; set; } = true;
    }
}
