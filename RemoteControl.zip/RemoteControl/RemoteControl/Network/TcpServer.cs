﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;

namespace RemoteControl.Network
{
    public class TcpServer
    {
        private TcpListener _listener;
        public List<TcpConnection> Clients { get; } = new();
        public event Action<TcpConnection>? OnClientConnected;
        public event Action<TcpConnection>? OnClientDisconnected;
        public event Action<TcpConnection, string>? OnClientAuthorized;

        public bool IsRunning { get; private set; }

        public async Task Start(int port)
        {
            if (IsRunning)
                return; // защита от повторного запуска

            IsRunning = true;

            _listener = new TcpListener(IPAddress.Any, port);
            _listener.Start();

            Debug.WriteLine("Сервер запущен!");

            try
            {
                while (true)
                {
                    var tcpClient = await _listener.AcceptTcpClientAsync();
                    var connection = new TcpConnection(tcpClient);

                    connection.OnMessage += (header, data) =>
                    {
                        HandleMessage(connection, header, data);
                    };

                    connection.OnDisconnected += () =>
                    {
                        OnClientDisconnected?.Invoke(connection);
                    };
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine("Ошибка сервера: " + ex.Message);
                IsRunning = false;
            }
        }

        private async void HandleMessage(TcpConnection connection, MessageHeader header, byte[] data)
        {
            if (header.Type == MessageType.Auth)
            {
                var payload = Encoding.UTF8.GetString(data);
                var parts = payload.Split('|');

                var code = parts[0];
                var deviceId = parts.Length > 1 ? parts[1] : "unknown";

                OnClientAuthorized?.Invoke(connection, deviceId);
            }
        }
    }
}
