﻿using System;
using System.Net.Sockets;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;

namespace RemoteControl.Network
{
    public class TcpConnection
    {
        private readonly TcpClient _client;
        private readonly NetworkStream _stream;

        public event Action<MessageHeader, byte[]>? OnMessage;
        public event Action? OnDisconnected;

        public string RemoteEndPoint =>
            _client.Client.RemoteEndPoint?.ToString() ?? "Unknown";

        public TcpConnection(TcpClient client)
        {
            _client = client;
            _stream = client.GetStream();

            Task.Run(Listen);
        }

        private async Task Listen()
        {
            try
            {
                while (true)
                {
                    byte[] lengthBuffer = new byte[4];
                    await _stream.ReadExactAsync(lengthBuffer, 4);

                    int jsonLength = BitConverter.ToInt32(lengthBuffer);

                    byte[] jsonBuffer = new byte[jsonLength];
                    await _stream.ReadExactAsync(jsonBuffer, jsonLength);

                    var header = JsonSerializer.Deserialize<MessageHeader>(jsonBuffer)!;

                    byte[] data = new byte[header.DataLength];
                    if (header.DataLength > 0)
                        await _stream.ReadExactAsync(data, header.DataLength);

                    OnMessage?.Invoke(header, data);
                }
            }
            catch
            {
                OnDisconnected?.Invoke();
            }
        }

        public async Task SendAsync(MessageHeader header, byte[]? data = null)
        {
            data ??= Array.Empty<byte>();
            header.DataLength = data.Length;

            var json = JsonSerializer.Serialize(header);
            var jsonBytes = Encoding.UTF8.GetBytes(json);

            // отправка длины JSON
            await _stream.WriteAsync(BitConverter.GetBytes(jsonBytes.Length));

            // отправка JSON
            await _stream.WriteAsync(jsonBytes);

            // отправка данных
            if (data.Length > 0)
                await _stream.WriteAsync(data);
        }

        public void Close()
        {
            try
            {
                _client.Close();
            }

            catch { }

            OnDisconnected?.Invoke();
        }
    }
}
