﻿namespace RemoteControl.Network
{
    public enum MessageType
    {
        Auth,
        Text,
        File,
        Screenshot,
        Frame,
        Command,
        Clipboard,
        Disconnect,
        Input
    }
}
