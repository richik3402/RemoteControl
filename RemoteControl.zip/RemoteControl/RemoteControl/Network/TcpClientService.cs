﻿using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;

namespace RemoteControl.Network
{
    public class TcpClientService
    {
        public TcpConnection Connection { get; private set; }

        public async Task Connect(string ip, int port)
        {
            var client = new TcpClient();
            await client.ConnectAsync(ip, port);

            Connection = new TcpConnection(client);
        }

        public async Task SendAuth(string code, string deviceId)
        {
            var payload = $"{code}|{deviceId}";
            var data = Encoding.UTF8.GetBytes(payload);

            await Connection.SendAsync(new MessageHeader
            {
                Type = MessageType.Auth
            }, data);
        }
    }
}
