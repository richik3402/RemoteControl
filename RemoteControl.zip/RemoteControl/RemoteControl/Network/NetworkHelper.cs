﻿using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.NetworkInformation;
using System.Net.Sockets;

namespace RemoteControl.Network
{
    public class NetworkAdapterInfo
    {
        public string Id { get; set; }
        public string Name { get; set; }
        public string Ip { get; set; }

        public override string ToString()
    => $"{Name} — {Ip}";
    }

    public static class NetworkHelper
    {
        public static List<NetworkAdapterInfo> GetAdapters()
        {
            var list = new List<NetworkAdapterInfo>();

            foreach (var ni in NetworkInterface.GetAllNetworkInterfaces())
            {
                if (ni.OperationalStatus != OperationalStatus.Up)
                    continue;

                var ip = ni.GetIPProperties()
                    .UnicastAddresses
                    .FirstOrDefault(a =>
                        a.Address.AddressFamily == AddressFamily.InterNetwork &&
                        !IPAddress.IsLoopback(a.Address));

                if (ip == null)
                    continue;

                list.Add(new NetworkAdapterInfo
                {
                    Id = ni.Id,
                    Name = ni.Name,
                    Ip = ip.Address.ToString()
                });
            }

            return list;
        }

        public static string GetIpByAdapter(string adapterId)
        {
            return GetAdapters()
                .FirstOrDefault(a => a.Id == adapterId)?.Ip
                ?? "127.0.0.1";
        }
    }
}
