﻿using System;
using System.Net.Sockets;
using System.Threading.Tasks;

namespace RemoteControl.Network
{
    public static class NetworkStreamExtensions
    {
        public static async Task ReadExactAsync(this NetworkStream stream, byte[] buffer, int size)
        {
            int total = 0;

            while (total < size)
            {
                int read = await stream.ReadAsync(buffer, total, size - total);
                if (read == 0)
                    throw new Exception("Соединение прервано!");

                total += read;
            }
        }
    }
}
