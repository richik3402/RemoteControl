﻿public class InputMessage
{
    public string Type { get; set; }

    // 🖱 МЫШЬ
    public double X { get; set; }
    public double Y { get; set; }
    public string MouseAction { get; set; }
    public int WheelDelta { get; set; }

    // ⌨ КЛАВИАТУРА
    public int KeyCode { get; set; }
    public int ScanCode { get; set; }
    public string KeyAction { get; set; }
    public string? Text { get; set; }
}
