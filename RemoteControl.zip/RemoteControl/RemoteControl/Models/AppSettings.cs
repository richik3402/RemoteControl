﻿namespace RemoteControl.Models
{
    public class AppSettings
    {
        // Сеть
        public bool AutoIp { get; set; } = true;
        public string IpAddress { get; set; } = "";
        public string SelectedAdapterId { get; set; } = "";
        public int Port { get; set; } = 5000;

        // Стрим
        public int StreamResolution { get; set; } = 1280;
        public int StreamQuality { get; set; } = 50;
        public int FPS { get; set; } = 10;
    }
}
