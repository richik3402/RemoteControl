﻿using RemoteControl.Network;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using System.Text.Json.Serialization;

namespace RemoteControl.Models
{
    public class ClientInfo : INotifyPropertyChanged
    {
        public string Ip { get; set; } = "";
        private string _name = "Новое устройство";
        public string Name
        {
            get => _name;
            set
            {
                _name = value;
                OnPropertyChanged();
            }
        }
        public event PropertyChangedEventHandler? PropertyChanged;
        protected void OnPropertyChanged([CallerMemberName] string? name = null)
            => PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
        public bool AllowMouse { get; set; } = true;
        public bool AllowKeyboard { get; set; } = true;
        public string Id => Ip;

        [JsonIgnore]
        public TcpConnection Connection { get; set; }
        [JsonIgnore]
        public bool IsOnline { get; set; }
    }
}
