using Avalonia.Controls;
using Avalonia.Controls.Templates;
using System;

namespace RemoteControl
{
    public class ViewLocator : IDataTemplate
    {
        public Control Build(object data)
        {
            if (data == null)
                return new TextBlock { Text = "Null data" };

            var type = data.GetType();

            if (!type.Name.EndsWith("ViewModel"))
                return new TextBlock { Text = data.ToString() };

            var viewName = type.FullName!
                .Replace("ViewModel", "View")
                .Replace("ViewModels", "Views");

            var viewType = Type.GetType(viewName);

            if (viewType == null)
                return new TextBlock { Text = "View not found: " + viewName };

            return (Control)Activator.CreateInstance(viewType)!;
        }

        public bool Match(object data)
        {
            return data is not null;
        }
    }
}
