﻿using System.Collections.Generic;
using System.Net.NetworkInformation;
using System.Threading.Tasks;

namespace RemoteControl.Utils
{
    public class NetworkScanner
    {
        public async Task<List<string>> ScanLocalNetwork(string baseIp)
        {
            var result = new List<string>();
            var tasks = new List<Task>();

            for (int i = 1; i < 255; i++)
            {
                string ip = $"{baseIp}.{i}";

                tasks.Add(Task.Run(async () =>
                {
                    using var ping = new Ping();
                    var reply = await ping.SendPingAsync(ip, 100);

                    if (reply.Status == IPStatus.Success)
                    {
                        lock (result)
                        {
                            result.Add(ip);
                        }
                    }
                }));
            }

            await Task.WhenAll(tasks);

            return result;
        }
    }
}
