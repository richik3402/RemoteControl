﻿using Avalonia;
using Avalonia.Controls;
using Avalonia.Controls.ApplicationLifetimes;
using Avalonia.Input;
using Avalonia.Media.Imaging;
using Avalonia.Threading;
using RemoteControl.Models;
using RemoteControl.Network;
using RemoteControl.Services;
using RemoteControl.Utils;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Net.Sockets;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;

namespace RemoteControl.ViewModels
{
    public class ServerViewModel : ViewModelBase
    {
        // =========================
        // 📦 ДАННЫЕ
        // =========================
        private List<ClientInfo> _savedClients = new();
        public ObservableCollection<ClientInfo> Clients { get; } = new();

        private ClientInfo? _selectedClient;
        public ClientInfo? SelectedClient
        {
            get => _selectedClient;
            set
            {
                _selectedClient = value;
                OnPropertyChanged();
                RaiseClientCommands();
            }
        }

        private readonly ServerService _serverService = new();
        private ServerSettingsWindow? _settingsWindow;

        public string CurrentIp
        {
            get
            {
                var settings = SettingsService.Current;

                if (settings.AutoIp)
                    return NetworkHelper.GetIpByAdapter(settings.SelectedAdapterId);

                return settings.IpAddress;
            }
        }

        public int Port
        {
            get
            {
                var settings = SettingsService.Current;

                return settings.Port;
            }
        }

        // =========================
        // 🎥 СОСТОЯНИЕ
        // =========================
        private bool _isServerRunning;
        public bool IsServerRunning
        {
            get => _isServerRunning;
            set { _isServerRunning = value; OnPropertyChanged(); }
        }

        private bool _isStreaming;
        public bool IsStreaming
        {
            get => _isStreaming;
            set { _isStreaming = value; OnPropertyChanged(); }
        }

        private Bitmap? _screenshot;
        public Bitmap? Screenshot
        {
            get => _screenshot;
            set { _screenshot = value; OnPropertyChanged(); }
        }

        private Bitmap? _frame;
        public Bitmap? Frame
        {
            get => _frame;
            set { _frame = value; OnPropertyChanged(); }
        }

        // =========================
        // 🎮 КОМАНДЫ
        // =========================
        public RelayCommand StartServerCommand { get; }
        public RelayCommand ShutdownCommand { get; }
        public RelayCommand RestartCommand { get; }
        public RelayCommand ClipboardCommand { get; }
        public RelayCommand ScreenshotCommand { get; }
        public RelayCommand ToggleStreamCommand { get; }
        public RelayCommand ForgetClientCommand { get; }
        public RelayCommand OpenSettingsCommand { get; }
        public RelayCommand<ClientInfo> OpenClientSettingsCommand { get; }

        public ServerViewModel()
        {
            _savedClients = ClientStorageService.Load();

            _serverService.OnClientConnected += HandleClient;
            ServerSettingsViewModel.SettingsChanged += ApplyServerSettings;

            OpenClientSettingsCommand = new RelayCommand<ClientInfo>(OpenClientSettings);

            StartServerCommand = new RelayCommand(StartServer, () => !IsServerRunning);
            ShutdownCommand = new RelayCommand(async () => await SendCommand(CommandType.Shutdown), CanControlClient);
            RestartCommand = new RelayCommand(async () => await SendCommand(CommandType.Restart), CanControlClient);
            ClipboardCommand = new RelayCommand(async () => await RequestClipboard(), CanControlClient);
            ScreenshotCommand = new RelayCommand(async () => await RequestScreenshot(), CanControlClient);
            ToggleStreamCommand = new RelayCommand(async () => await ToggleStream(), CanControlClient);
            ForgetClientCommand = new RelayCommand(ForgetClient, () => SelectedClient != null);
            OpenSettingsCommand = new RelayCommand(OpenSettings);
        }

        private void RaiseClientCommands()
        {
            ShutdownCommand.RaiseCanExecuteChanged();
            RestartCommand.RaiseCanExecuteChanged();
            ClipboardCommand.RaiseCanExecuteChanged();
            ScreenshotCommand.RaiseCanExecuteChanged();
            ToggleStreamCommand.RaiseCanExecuteChanged();
            ForgetClientCommand.RaiseCanExecuteChanged();
        }

        private bool CanControlClient()
        {
            Debug.WriteLine($"Selected: {SelectedClient != null}, Online: {SelectedClient?.IsOnline}");
            return SelectedClient != null && SelectedClient.IsOnline;
        }

        // =========================
        // 🚀 СЕРВЕР
        // =========================
        private bool IsValidIp(string ip)
        {
            return System.Net.IPAddress.TryParse(ip, out _);
        }

        private void StartServer()
        {
            var settings = SettingsService.Current;

            var ip = settings.AutoIp
                ? NetworkHelper.GetIpByAdapter(settings.SelectedAdapterId)
                : settings.IpAddress;

            if (!System.Net.IPAddress.TryParse(ip, out _))
            {
                Debug.WriteLine("Некорректный IP!");
                return;
            }

            if (string.IsNullOrWhiteSpace(ip) || !IsValidIp(ip))
            {
                Debug.WriteLine("Некорректный IP!");
                return;
            }

            _serverService.Stop();
            _serverService.Start(ip, settings.Port);

            IsServerRunning = true;
            OnPropertyChanged(nameof(IsServerRunning));
            StartServerCommand.RaiseCanExecuteChanged();
        }

        private void HandleClient(TcpClient tcpClient)
        {
            _ = Task.Run(() =>
            {
                var connection = new TcpConnection(tcpClient);
                string ip = ((System.Net.IPEndPoint)tcpClient.Client.RemoteEndPoint!).Address.ToString();

                connection.OnMessage += (header, data) =>
                {
                    try
                    {
                        if (header.Type == MessageType.Screenshot)
                        {
                            var ms = new MemoryStream(data);
                            var bitmap = new Avalonia.Media.Imaging.Bitmap(ms);

                            Dispatcher.UIThread.Post(() =>
                            {
                                Screenshot = bitmap;
                                Debug.WriteLine("📸 Screenshot RECEIVED");
                            });
                        }

                        else if (header.Type == MessageType.Frame)
                        {
                            using var ms = new MemoryStream(data);
                            var bitmap = new Avalonia.Media.Imaging.Bitmap(ms);

                            Dispatcher.UIThread.Post(() =>
                            {
                                Frame = bitmap;
                                Debug.WriteLine("🎥 Frame RECEIVED");
                            });
                        }

                        else if (header.Type == MessageType.Clipboard)
                        {
                            var text = Encoding.UTF8.GetString(data);

                            Dispatcher.UIThread.Post(async () =>
                            {
                                var topLevel = TopLevel.GetTopLevel(
                                    (Application.Current?.ApplicationLifetime
                                     as IClassicDesktopStyleApplicationLifetime)?.MainWindow);

                                if (topLevel?.Clipboard != null)
                                    await topLevel.Clipboard.SetTextAsync(text);
                            });
                        }
                    }
                    catch (Exception ex)
                    {
                        Debug.WriteLine("❌ RECEIVE ERROR: " + ex);
                    }
                };

                Dispatcher.UIThread.Post(() =>
                {
                    var saved = _savedClients.FirstOrDefault(c => c.Ip == ip);

                    ClientInfo client;

                    if (saved != null)
                    {
                        client = saved;
                        client.IsOnline = true;
                        client.Connection = connection;

                        if (!Clients.Contains(client))
                            Clients.Add(client);
                    }
                    else
                    {
                        client = new ClientInfo
                        {
                            Ip = ip,
                            Name = "Новое устройство",
                            IsOnline = true,
                            AllowMouse = true,
                            AllowKeyboard = true,
                            Connection = connection
                        };

                        Clients.Add(client);
                        _savedClients.Add(client);
                    }

                    ClientStorageService.Save(_savedClients);

                    // 🔥 отправляем настройки клиенту
                    _ = SendClientSettings(client);

                    RaiseClientCommands();
                });

                connection.OnDisconnected += () =>
                {
                    Dispatcher.UIThread.Post(() =>
                    {
                        var client = Clients.FirstOrDefault(c => c.Connection == connection);
                        if (client != null)
                        {
                            client.IsOnline = false;
                            Clients[Clients.IndexOf(client)] = client;
                        }
                    });
                };
            });
        }

        private void ForgetClient()
        {
            if (SelectedClient == null)
                return;

            var ip = SelectedClient.Ip;

            SelectedClient.Connection?.Close();
            Clients.Remove(SelectedClient);

            if (!string.IsNullOrEmpty(ip))
                _savedClients.RemoveAll(c => c.Ip == ip);

            ClientStorageService.Save(_savedClients);

            SelectedClient = null;
        }

        // =========================
        // ⚙ НАСТРОЙКИ КЛИЕНТА
        // =========================
        private void OpenClientSettings(ClientInfo? client)
        {
            if (client == null) return;

            var vm = new ClientSettingsViewModel(client);

            var window = new ClientSettingsWindow
            {
                DataContext = vm
            };

            vm.CloseAction = () => window.Close();

            window.Closed += async (_, __) =>
            {
                ClientStorageService.Save(_savedClients);
                await SendClientSettings(client);
            };

            window.Show();
        }

        // =========================
        // 📡 КОМАНДЫ
        // =========================
        private async Task SendCommand(CommandType commandType)
        {
            if (SelectedClient?.IsOnline != true) return;

            var cmd = new CommandMessage { Command = commandType };

            await SelectedClient.Connection.SendAsync(
                new MessageHeader { Type = MessageType.Command },
                Encoding.UTF8.GetBytes(JsonSerializer.Serialize(cmd)));

            Debug.WriteLine($"Sending command: {commandType}");
        }

        private Task RequestClipboard() => SendCommand(CommandType.ClipboardRequest);
        private Task RequestScreenshot() => SendCommand(CommandType.Screenshot);

        // =========================
        // 🎥 СТРИМ
        // =========================
        private async Task ToggleStream()
        {
            if (SelectedClient?.IsOnline != true) return;

            var cmdType = IsStreaming ? CommandType.StopStream : CommandType.StartStream;

            await SendCommand(cmdType);

            if (!IsStreaming)
                await SendStreamSettings();

            IsStreaming = !IsStreaming;
        }

        private async Task SendStreamSettings()
        {
            if (SelectedClient?.IsOnline != true) return;

            var settings = SettingsService.Current;

            var cmd = new CommandMessage
            {
                Command = CommandType.SetStreamSettings,
                Resolution = settings.StreamResolution,
                Quality = settings.StreamQuality,
                FPS = settings.FPS
            };

            await SelectedClient.Connection.SendAsync(
                new MessageHeader { Type = MessageType.Command },
                Encoding.UTF8.GetBytes(JsonSerializer.Serialize(cmd)));
        }

        private async Task SendClientSettings(ClientInfo? client)
        {
            if (client?.Connection == null) return;

            var cmd = new CommandMessage
            {
                Command = CommandType.SetClientSettings,
                AllowMouse = client.AllowMouse,
                AllowKeyboard = client.AllowKeyboard
            };

            await client.Connection.SendAsync(
                new MessageHeader { Type = MessageType.Command },
                Encoding.UTF8.GetBytes(JsonSerializer.Serialize(cmd)));
        }

        // =========================
        // 🖱 INPUT
        // =========================
        public async Task SendMouseMove(double x, double y)
        {
            if (!IsStreaming || SelectedClient == null || !SelectedClient.AllowMouse) return;

            Debug.WriteLine("SEND MOUSE");

            await SendInput(new InputMessage { Type = "mouse", X = x, Y = y, MouseAction = "move" });
        }

        public async Task SendMouseClick(string action)
        {
            if (!IsStreaming || SelectedClient == null || !SelectedClient.AllowMouse) return;

            await SendInput(new InputMessage { Type = "mouse", MouseAction = action });
        }

        public async Task SendMouseWheel(int delta)
        {
            if (!IsStreaming || SelectedClient == null || !SelectedClient.AllowMouse) return;

            await SendInput(new InputMessage { Type = "mouse", MouseAction = "wheel", WheelDelta = delta });
        }

        public async Task SendKey(KeyEventArgs e, bool isDown)
        {
            if (!IsStreaming || SelectedClient == null || !SelectedClient.AllowKeyboard)
                return;

            var key = e.Key;

            int vk = key switch
            {
                Avalonia.Input.Key.Space => 0x20,
                Avalonia.Input.Key.Enter => 0x0D,
                Avalonia.Input.Key.Back => 0x08,
                Avalonia.Input.Key.Tab => 0x09,
                Avalonia.Input.Key.LeftShift => 0xA0,
                Avalonia.Input.Key.RightShift => 0xA1,
                Avalonia.Input.Key.LeftCtrl => 0xA2,
                Avalonia.Input.Key.RightCtrl => 0xA3,

                _ => 0
            };

            if (vk == 0)
                return;

            await SendInput(new InputMessage
            {
                Type = "keyboard",
                KeyCode = vk,
                KeyAction = isDown ? "down" : "up"
            });
        }

        public async Task SendText(string text)
        {
            if (!IsStreaming || SelectedClient == null || !SelectedClient.AllowKeyboard)
                return;

            await SendInput(new InputMessage
            {
                Type = "text",
                Text = text
            });
        }

        private async Task SendInput(InputMessage msg)
        {
            if (SelectedClient?.Connection == null) return;

            await SelectedClient.Connection.SendAsync(
                new MessageHeader { Type = MessageType.Input },
                Encoding.UTF8.GetBytes(JsonSerializer.Serialize(msg)));
        }

        // =========================
        // ⚙ НАСТРОЙКИ СЕРВЕРА
        // =========================
        private void OpenSettings()
        {
            if (_settingsWindow != null)
            {
                _settingsWindow.Close();
                _settingsWindow = null;
                return;
            }

            var vm = new ServerSettingsViewModel();
            vm.LoadFrom(SettingsService.Current);

            _settingsWindow = new ServerSettingsWindow { DataContext = vm };

            vm.CloseAction = () =>
            {
                _settingsWindow?.Close();
                _settingsWindow = null;
            };

            _settingsWindow.Show();
        }

        private void ApplyServerSettings(AppSettings settings)
        {
            if (!_serverService.IsRunning) return;

            var ip = settings.AutoIp
                ? NetworkHelper.GetIpByAdapter(settings.SelectedAdapterId)
                : settings.IpAddress;

            if (_serverService.Port != settings.Port || _serverService.IpAddress != ip)
                _serverService.Restart(ip, settings.Port);

            if (SelectedClient?.IsOnline == true)
                _ = SendStreamSettings();

            OnPropertyChanged(nameof(CurrentIp));
        }
    }
}

