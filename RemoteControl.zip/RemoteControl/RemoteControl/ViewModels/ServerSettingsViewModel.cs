﻿using RemoteControl.Models;
using RemoteControl.Network;
using RemoteControl.Services;
using RemoteControl.Utils;
using System;
using System.Collections.Generic;
using System.Linq;

namespace RemoteControl.ViewModels
{
    public class ServerSettingsViewModel : ViewModelBase
    {
        private AppSettings _settings = new AppSettings();

        private bool _autoIp;
        public bool AutoIp
        {
            get => _autoIp;
            set
            {
                _autoIp = value;
                OnPropertyChanged();
                OnPropertyChanged(nameof(IsManualIp));
                UpdateIp();
            }
        }

        public bool IsManualIp => !AutoIp;

        private string _ipAddress;
        public string IpAddress
        {
            get => _ipAddress;
            set { _ipAddress = value; OnPropertyChanged(); }
        }
        public List<NetworkAdapterInfo> Adapters { get; set; }

        private NetworkAdapterInfo _selectedAdapter;
        public NetworkAdapterInfo SelectedAdapter
        {
            get => _selectedAdapter;
            set
            {
                _selectedAdapter = value;
                OnPropertyChanged();

                if (value != null)
                    IpAddress = value.Ip;
            }
        }

        private string? _ipError;
        public string? IpError
        {
            get => _ipError;
            set { _ipError = value; OnPropertyChanged(); }
        }

        private string? _portError;
        public string? PortError
        {
            get => _portError;
            set { _portError = value; OnPropertyChanged(); }
        }

        public string Port
        {
            get => _settings.Port.ToString();
            set
            {
                OnPropertyChanged();
            }
        }

        public string StreamResolution
        {
            get => _settings.StreamResolution.ToString();
            set
            {
                if (int.TryParse(value, out int res))
                    _settings.StreamResolution = res;

                OnPropertyChanged();
            }
        }

        public int StreamQuality
        {
            get => _settings.StreamQuality;
            set
            {
                _settings.StreamQuality = value;
                OnPropertyChanged();
            }
        }

        public int FPS
        {
            get => _settings.FPS;
            set
            {
                _settings.FPS = value;
                OnPropertyChanged();
            }
        }

        public RelayCommand SaveCommand { get; }
        public RelayCommand CancelCommand { get; }
        public RelayCommand ResetCommand { get; }

        public Action? CloseAction;
        public static Action<AppSettings>? SettingsChanged;

        public ServerSettingsViewModel()
        {
            SaveCommand = new RelayCommand(Save);
            CancelCommand = new RelayCommand(Cancel);
            ResetCommand = new RelayCommand(Reset);
        }

        private void UpdateIp()
        {
            if (AutoIp)
                IpAddress = NetworkHelper.GetIpByAdapter(SelectedAdapter?.Id);
        }

        public void LoadFrom(AppSettings settings)
        {
            Adapters = NetworkHelper.GetAdapters();
            OnPropertyChanged(nameof(Adapters));

            AutoIp = settings.AutoIp;
            IpAddress = settings.IpAddress;

            if (AutoIp)
            {
                SelectedAdapter = Adapters
                    .FirstOrDefault(a => a.Id == settings.SelectedAdapterId)
                    ?? Adapters.FirstOrDefault();

                if (SelectedAdapter != null)
                    IpAddress = SelectedAdapter.Ip;
            }

            Port = settings.Port.ToString();

            StreamResolution = settings.StreamResolution.ToString();
            StreamQuality = settings.StreamQuality;
            FPS = settings.FPS;
        }

        private void Save()
        {
            if (!Validate())
                return;


            var settings = new AppSettings
            {
                AutoIp = AutoIp,
                IpAddress = IpAddress,
                SelectedAdapterId = SelectedAdapter?.Id ?? "",
                Port = int.Parse(Port),
                StreamResolution = int.Parse(StreamResolution),
                StreamQuality = StreamQuality,
                FPS = FPS
            };

            SettingsService.Save(settings);

            SettingsChanged?.Invoke(settings);

            CloseAction?.Invoke();
        }

        private void Cancel()
        {
            CloseAction?.Invoke();
        }

        private void Reset()
        {
            SettingsService.Reset();
            LoadFrom(SettingsService.Current);
        }

        private bool Validate()
        {
            IpError = null;
            PortError = null;

            bool isValid = true;

            if (!System.Net.IPAddress.TryParse(IpAddress, out _))
            {
                IpError = "Ошибка: неверно указан IP-адрес";
                isValid = false;
            }

            if (!System.Int32.TryParse(Port, out int port) || port < 1 || port > 65535)
            {
                PortError = "Ошибка: некорректный порт";
                isValid = false;
            }

            return isValid;
        }
    }
}
