﻿using RemoteControl.Models;
using RemoteControl.Utils;
using System;

namespace RemoteControl.ViewModels
{
    public class ClientSettingsViewModel : ViewModelBase
    {
        private string _name;
        public string Name
        {
            get => _name;
            set
            {
                _name = value;
                OnPropertyChanged();
            }
        }
        private bool _allowMouse = true;
        public bool AllowMouse
        {
            get => _allowMouse;
            set
            {
                _allowMouse = value;
                OnPropertyChanged();
            }
        }

        private bool _allowKeyboard = true;
        public bool AllowKeyboard
        {
            get => _allowKeyboard;
            set
            {
                _allowKeyboard = value;
                OnPropertyChanged();
            }
        }

        private readonly ClientInfo _client;

        public Action? CloseAction;

        public RelayCommand SaveCommand { get; }
        public RelayCommand CancelCommand { get; }
        public RelayCommand ResetCommand { get; }

        public ClientSettingsViewModel(ClientInfo client)
        {
            _client = client;

            Name = client.Name;
            AllowMouse = client.AllowMouse;
            AllowKeyboard = client.AllowKeyboard;

            SaveCommand = new RelayCommand(Save);
            CancelCommand = new RelayCommand(() => CloseAction?.Invoke());
            ResetCommand = new RelayCommand(Reset);
        }

        private void Save()
        {
            _client.Name = Name;
            _client.AllowMouse = AllowMouse;
            _client.AllowKeyboard = AllowKeyboard;

            CloseAction?.Invoke();
        }

        private void Reset()
        {
            Name = "Новое устройство";
            AllowMouse = true;
            AllowKeyboard = true;

            OnPropertyChanged(nameof(Name));
            OnPropertyChanged(nameof(AllowMouse));
            OnPropertyChanged(nameof(AllowKeyboard));
        }
    }
}
