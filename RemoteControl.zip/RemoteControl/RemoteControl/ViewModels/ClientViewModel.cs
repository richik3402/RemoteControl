﻿using Avalonia;
using RemoteControl.Network;
using RemoteControl.Utils;
using System;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Text.Json;
using System.Threading;
using System.Threading.Tasks;

using DrawingBitmap = System.Drawing.Bitmap;

namespace RemoteControl.ViewModels
{
    public class ClientViewModel : ViewModelBase
    {
        public string Ip { get; set; } = "";
        public string Status { get; set; } = "";

        private string _port = "";
        public string Port
        {
            get => _port;
            set { _port = value; OnPropertyChanged(); }
        }

        private bool _isConnecting;
        private bool _isStreaming;

        private bool _allowMouse = true;
        private bool _allowKeyboard = true;

        private CancellationTokenSource? _streamCts;

        private int _targetWidth = 1280;
        private int _jpegQuality = 50;
        private int _frameDelay = 100;

        public RelayCommand ConnectCommand { get; }

        private TcpClientService _client = new();

        public ClientViewModel()
        {
            ConnectCommand = new RelayCommand(async () => await Connect());
        }

        private async Task Connect()
        {
            if (_isConnecting) return;
            _isConnecting = true;

            try
            {
                Status = "Подключение...";
                OnPropertyChanged(nameof(Status));

                if (!int.TryParse(Port, out int port))
                {
                    Status = "Некорректный порт";
                    OnPropertyChanged(nameof(Status));
                    return;
                }

                await _client.Connect(Ip, port);
                _client.Connection.OnMessage += OnMessageReceived;

                Status = "Подключено!";
                OnPropertyChanged(nameof(Status));
            }
            catch (Exception ex)
            {
                Status = "Ошибка: " + ex.Message;
                OnPropertyChanged(nameof(Status));
            }
            finally
            {
                _isConnecting = false;
            }
        }

        private void OnMessageReceived(MessageHeader header, byte[] data)
        {
            Debug.WriteLine($"RECEIVED TYPE: {header.Type}");
            if (header.Type == MessageType.Command)
            {
                var cmd = JsonSerializer.Deserialize<CommandMessage>(Encoding.UTF8.GetString(data));

                if (cmd != null)
                {
                    Avalonia.Threading.Dispatcher.UIThread.Post(() =>
                    {
                        HandleCommand(cmd);
                    });
                }
            }
            else if (header.Type == MessageType.Input)
            {
                var input = JsonSerializer.Deserialize<InputMessage>(Encoding.UTF8.GetString(data));

                if (input != null)
                {
                    Avalonia.Threading.Dispatcher.UIThread.Post(() =>
                    {
                        HandleInput(input);
                    });
                }
            }
        }

        private void HandleCommand(CommandMessage cmd)
        {

            Debug.WriteLine("Command received: " + cmd.Command);
            switch (cmd.Command)
            {
                case CommandType.Shutdown: Shutdown(); break;
                case CommandType.Restart: Restart(); break;
                case CommandType.ClipboardRequest: SendClipboard(); break;
                case CommandType.Screenshot: TakeScreenshot(); break;
                case CommandType.StartStream: StartStreaming(); break;
                case CommandType.StopStream: StopStreaming(); break;
                case CommandType.SetStreamSettings: ApplyStreamSettings(cmd); break;

                case CommandType.SetClientSettings:
                    _allowMouse = cmd.AllowMouse;
                    _allowKeyboard = cmd.AllowKeyboard;
                    break;
            }
        }

        private void HandleInput(InputMessage input)
        {
            Debug.WriteLine($"INPUT: {input.Type}, action={input.MouseAction}, key={input.KeyAction}");
            if (!_isStreaming) return;

            if (input.Type == "mouse")
            {
                if (!_allowMouse) return;

                switch (input.MouseAction)
                {
                    case "move":
                        var screen = System.Windows.Forms.Screen.PrimaryScreen.Bounds;

                        int x = (int)(input.X * 65535);
                        int y = (int)(input.Y * 65535);
                        SendMouse(x, y, MOUSEEVENTF_MOVE | MOUSEEVENTF_ABSOLUTE | MOUSEEVENTF_VIRTUALDESK);
                        break;

                    case "left_down":
                        MouseClick(MOUSEEVENTF_LEFTDOWN); break;

                    case "left_up":
                        MouseClick(MOUSEEVENTF_LEFTUP); break;

                    case "right_down":
                        MouseClick(MOUSEEVENTF_RIGHTDOWN); break;

                    case "right_up":
                        MouseClick(MOUSEEVENTF_RIGHTUP); break;

                    case "wheel":
                        MouseWheel(input.WheelDelta); break;
                }
            }

            else if (input.Type == "keyboard")
            {
                if (!_allowKeyboard) return;
                SimulateKey(input.KeyCode, input.KeyAction == "down");
            }

            else if (input.Type == "text")
            {
                if (!_allowKeyboard)
                    return;

                if (!string.IsNullOrEmpty(input.Text))
                    SimulateText(input.Text);
            }
        }

        // INPUT

        [StructLayout(LayoutKind.Sequential)]
        struct INPUT { public int type; public InputUnion U; }

        [StructLayout(LayoutKind.Explicit)]
        struct InputUnion
        {
            [FieldOffset(0)] public MOUSEINPUT mi;
            [FieldOffset(0)] public KEYBDINPUT ki;
        }

        [StructLayout(LayoutKind.Sequential)]
        struct MOUSEINPUT
        {
            public int dx, dy, mouseData;
            public uint dwFlags, time;
            public IntPtr dwExtraInfo;
        }

        [StructLayout(LayoutKind.Sequential)]
        struct KEYBDINPUT
        {
            public ushort wVk, wScan;
            public uint dwFlags, time;
            public IntPtr dwExtraInfo;
        }

        [DllImport("user32.dll")]
        static extern uint SendInput(uint nInputs, INPUT[] pInputs, int cbSize);

        const int INPUT_MOUSE = 0;
        const int INPUT_KEYBOARD = 1;

        const uint MOUSEEVENTF_VIRTUALDESK = 0x4000;
        const uint MOUSEEVENTF_MOVE = 0x0001;
        const uint MOUSEEVENTF_ABSOLUTE = 0x8000;
        const uint MOUSEEVENTF_LEFTDOWN = 0x0002;
        const uint MOUSEEVENTF_LEFTUP = 0x0004;
        const uint MOUSEEVENTF_RIGHTDOWN = 0x0008;
        const uint MOUSEEVENTF_RIGHTUP = 0x0010;

        const uint KEYEVENTF_SCANCODE = 0x0008;
        const uint KEYEVENTF_KEYUP = 0x0002;

        const uint KEYEVENTF_UNICODE = 0x0004;

        private void SendMouse(int dx, int dy, uint flags)
        {
            var input = new INPUT
            {
                type = INPUT_MOUSE,
                U = new InputUnion
                {
                    mi = new MOUSEINPUT { dx = dx, dy = dy, dwFlags = flags }
                }
            };

            SendInput(1, new[] { input }, Marshal.SizeOf(typeof(INPUT)));
        }

        private void MouseClick(uint flag)
        {
            var input = new INPUT
            {
                type = INPUT_MOUSE,
                U = new InputUnion
                {
                    mi = new MOUSEINPUT { dwFlags = flag }
                }
            };

            SendInput(1, new[] { input }, Marshal.SizeOf(typeof(INPUT)));
        }

        private void MouseWheel(int delta)
        {
            var input = new INPUT
            {
                type = INPUT_MOUSE,
                U = new InputUnion
                {
                    mi = new MOUSEINPUT
                    {
                        mouseData = delta,
                        dwFlags = 0x0800 // MOUSEEVENTF_WHEEL
                    }
                }
            };

            SendInput(1, new[] { input }, Marshal.SizeOf(typeof(INPUT)));
        }

        private void SimulateKey(int vk, bool down)
        {
            var input = new INPUT
            {
                type = INPUT_KEYBOARD,
                U = new InputUnion
                {
                    ki = new KEYBDINPUT
                    {
                        wVk = (ushort)vk,
                        wScan = 0,
                        dwFlags = down ? 0u : KEYEVENTF_KEYUP
                    }
                }
            };

            SendInput(1, new[] { input }, Marshal.SizeOf(typeof(INPUT)));
        }

        private void SimulateText(string text)
        {
            foreach (char c in text)
            {
                var down = new INPUT
                {
                    type = INPUT_KEYBOARD,
                    U = new InputUnion
                    {
                        ki = new KEYBDINPUT
                        {
                            wVk = 0,
                            wScan = c,
                            dwFlags = KEYEVENTF_UNICODE
                        }
                    }
                };

                var up = new INPUT
                {
                    type = INPUT_KEYBOARD,
                    U = new InputUnion
                    {
                        ki = new KEYBDINPUT
                        {
                            wVk = 0,
                            wScan = c,
                            dwFlags = KEYEVENTF_UNICODE | KEYEVENTF_KEYUP
                        }
                    }
                };

                SendInput(1, new[] { down }, Marshal.SizeOf(typeof(INPUT)));
                SendInput(1, new[] { up }, Marshal.SizeOf(typeof(INPUT)));
            }
        }

        // STREAM

        private void StartStreaming()
        {
            StopStreaming();

            Debug.WriteLine("🎥 STREAM START");

            _isStreaming = true;
            _streamCts = new CancellationTokenSource();

            Task.Run(async () =>
            {
                while (!_streamCts.Token.IsCancellationRequested)
                {
                    try
                    {
                        var bounds = System.Windows.Forms.Screen.PrimaryScreen.Bounds;

                        using var original = new DrawingBitmap(bounds.Width, bounds.Height);
                        using var g = Graphics.FromImage(original);
                        g.CopyFromScreen(0, 0, 0, 0, bounds.Size);

                        int newWidth = _targetWidth;
                        int newHeight = original.Height * newWidth / original.Width;

                        using var resized = new DrawingBitmap(newWidth, newHeight);
                        using var g2 = Graphics.FromImage(resized);
                        g2.DrawImage(original, 0, 0, newWidth, newHeight);

                        using var ms = new MemoryStream();

                        var encoder = ImageCodecInfo.GetImageDecoders()
                            .First(c => c.FormatID == ImageFormat.Jpeg.Guid);

                        var ep = new EncoderParameters(1);
                        ep.Param[0] = new EncoderParameter(
                            System.Drawing.Imaging.Encoder.Quality,
                            (long)_jpegQuality);

                        resized.Save(ms, encoder, ep);

                        if (_client.Connection == null)
                        {
                            Debug.WriteLine("❌ STREAM: connection null");
                            break;
                        }

                        await _client.Connection.SendAsync(
                            new MessageHeader { Type = MessageType.Frame },
                            ms.ToArray());

                        Debug.WriteLine("🎥 Frame sent");
                    }
                    catch (Exception ex)
                    {
                        Debug.WriteLine("❌ STREAM ERROR: " + ex);
                        break;
                    }

                    await Task.Delay(_frameDelay);
                }

                Debug.WriteLine("🎥 STREAM STOPPED");
            });
        }

        private void StopStreaming()
        {
            _isStreaming = false;
            _streamCts?.Cancel();
        }

        private void ApplyStreamSettings(CommandMessage cmd)
        {
            if (cmd.Resolution > 0) _targetWidth = cmd.Resolution;
            if (cmd.Quality > 0) _jpegQuality = cmd.Quality;
            if (cmd.FPS > 0) _frameDelay = 1000 / cmd.FPS;
        }

        private void Shutdown()
        {
            Process.Start(new ProcessStartInfo
            {
                FileName = "shutdown",
                Arguments = "/s /t 0",
                CreateNoWindow = true,
                UseShellExecute = true
            });
        }

        private void Restart()
        {
            Process.Start(new ProcessStartInfo
            {
                FileName = "shutdown",
                Arguments = "/r /t 0",
                CreateNoWindow = true,
                UseShellExecute = true
            });
        }

        private async void SendClipboard()
        {
            try
            {
                var lifetime = Application.Current?.ApplicationLifetime
                    as Avalonia.Controls.ApplicationLifetimes.IClassicDesktopStyleApplicationLifetime;

                var window = lifetime?.MainWindow;

                if (window == null)
                    return;

                var clipboard = window.Clipboard;

                if (clipboard == null)
                    return;

                var text = await clipboard.GetTextAsync();

                await _client.Connection.SendAsync(
                    new MessageHeader { Type = MessageType.Clipboard },
                    Encoding.UTF8.GetBytes(text ?? ""));
            }
            catch (Exception ex)
            {
                Debug.WriteLine("Clipboard error: " + ex.Message);
            }
        }

        private async void TakeScreenshot()
        {
            try
            {
                Debug.WriteLine("📸 Screenshot START");

                var bounds = System.Windows.Forms.Screen.PrimaryScreen.Bounds;

                using var bmp = new DrawingBitmap(bounds.Width, bounds.Height);
                using var g = Graphics.FromImage(bmp);
                g.CopyFromScreen(0, 0, 0, 0, bounds.Size);

                using var ms = new MemoryStream();
                bmp.Save(ms, ImageFormat.Png);

                if (_client.Connection == null)
                {
                    Debug.WriteLine("❌ Connection NULL");
                    return;
                }

                await _client.Connection.SendAsync(
                    new MessageHeader { Type = MessageType.Screenshot },
                    ms.ToArray());

                Debug.WriteLine("📸 Screenshot SENT");
            }
            catch (Exception ex)
            {
                Debug.WriteLine("❌ Screenshot ERROR: " + ex);
            }
        }
    }
}
