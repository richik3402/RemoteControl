﻿using RemoteControl.Utils;

namespace RemoteControl.ViewModels
{
    public class MainWindowViewModel : ViewModelBase
    {
        private object _currentView;
        private string _currentMode;

        public object CurrentView
        {
            get => _currentView;
            set
            {
                _currentView = value;
                OnPropertyChanged();
            }
        }

        public string CurrentMode
        {
            get => _currentMode;
            set
            {
                _currentMode = value;
                OnPropertyChanged();

                SetClientModeCommand.RaiseCanExecuteChanged();
                SetServerModeCommand.RaiseCanExecuteChanged();
            }
        }

        public RelayCommand SetClientModeCommand { get; }
        public RelayCommand SetServerModeCommand { get; }

        public MainWindowViewModel()
        {
            SetClientModeCommand = new RelayCommand(
                SetClientMode,
                () => CurrentMode != "Запущен режим клиента"
            );

            SetServerModeCommand = new RelayCommand(
                SetServerMode,
                () => CurrentMode != "Запущен режим сервера"
            );

            SetClientMode();
        }

        private void SetClientMode()
        {
            CurrentMode = "Запущен режим клиента";
            CurrentView = new ClientViewModel();
        }

        private void SetServerMode()
        {
            CurrentMode = "Запущен режим сервера";
            CurrentView = new ServerViewModel();
        }
    }
}
