﻿using RemoteControl.Models;
using System.IO;
using System.Text.Json;

namespace RemoteControl.Services
{
    public static class SettingsService
    {
        private static readonly string FilePath = "settings.json";

        public static AppSettings Current { get; private set; } = Load();

        public static AppSettings Load()
        {
            if (!File.Exists(FilePath))
                return new AppSettings();

            var json = File.ReadAllText(FilePath);
            return JsonSerializer.Deserialize<AppSettings>(json) ?? new AppSettings();
        }

        public static void Save(AppSettings settings)
        {
            var json = JsonSerializer.Serialize(settings, new JsonSerializerOptions
            {
                WriteIndented = true
            });

            File.WriteAllText(FilePath, json);
            Current = settings;
        }

        public static void Reset()
        {
            Current = new AppSettings();
            Save(Current);
        }
    }
}
