﻿using RemoteControl.Models;
using System.Collections.Generic;
using System.IO;
using System.Text.Json;

namespace RemoteControl.Services
{
    public static class ClientStorageService
    {
        private static string FilePath => "clients.json";

        public static List<ClientInfo> Load()
        {
            if (!File.Exists(FilePath))
                return new List<ClientInfo>();

            var json = File.ReadAllText(FilePath);
            return JsonSerializer.Deserialize<List<ClientInfo>>(json) ?? new();
        }

        public static void Save(IEnumerable<ClientInfo> clients)
        {
            var json = JsonSerializer.Serialize(clients, new JsonSerializerOptions
            {
                WriteIndented = true
            });

            File.WriteAllText(FilePath, json);
        }
    }
}
