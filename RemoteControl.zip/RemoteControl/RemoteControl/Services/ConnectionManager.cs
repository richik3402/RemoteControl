﻿namespace RemoteControl.Services
{
    public class ConnectionManager
    {
        public bool IsConnected { get; set; }
        public string Mode { get; set; } = ""; // "Client" или "Server"
    }
}
