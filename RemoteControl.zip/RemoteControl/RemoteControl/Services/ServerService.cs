﻿using System;
using System.Net;
using System.Net.Sockets;
using System.Threading;

namespace RemoteControl.Services
{
    public class ServerService
    {
        private TcpListener? _listener;
        private CancellationTokenSource? _cts;

        public bool IsRunning { get; private set; }

        public int Port { get; private set; }
        public string IpAddress { get; private set; } = "0.0.0.0";

        public Action<TcpClient>? OnClientConnected;

        public void Start(string ip, int port)
        {
            if (IsRunning)
                return;

            IpAddress = ip;
            Port = port;

            var address = IPAddress.Parse(ip);

            _listener = new TcpListener(IPAddress.Parse(ip), port);
            _listener.Server.SetSocketOption(SocketOptionLevel.Socket, SocketOptionName.ReuseAddress, true);
            _listener.Start();

            _cts = new CancellationTokenSource();

            IsRunning = true;

            AcceptLoop(_cts.Token);
        }

        public void Stop()
        {
            if (!IsRunning)
                return;

            _cts?.Cancel();
            _listener?.Stop();

            IsRunning = false;
        }

        public void Restart(string ip, int port)
        {
            Stop();
            Start(ip, port);
        }

        private async void AcceptLoop(CancellationToken token)
        {
            try
            {
                while (!token.IsCancellationRequested)
                {
                    var client = await _listener!.AcceptTcpClientAsync(token);
                    OnClientConnected?.Invoke(client);
                }
            }
            catch
            {
                // игнор при остановке
            }
        }
    }
}
