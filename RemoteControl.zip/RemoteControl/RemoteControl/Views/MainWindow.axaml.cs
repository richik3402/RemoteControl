using Avalonia.Controls;
using RemoteControl.ViewModels;

namespace RemoteControl.Views
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            DataContext = new MainWindowViewModel();
        }
    }
}