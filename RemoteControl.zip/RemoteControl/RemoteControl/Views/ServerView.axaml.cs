using Avalonia.Controls;
using Avalonia.Input;
using RemoteControl.ViewModels;

namespace RemoteControl.Views
{
    public partial class ServerView : UserControl
    {
        public ServerView()
        {
            InitializeComponent();

            this.AttachedToVisualTree += (_, __) =>
            {
                this.Focus();
            };
        }

        private ServerViewModel VM => DataContext as ServerViewModel;

        private async void OnPointerMoved(object sender, PointerEventArgs e)
        {
            var control = (Control)sender;
            var p = e.GetPosition(control);

            double normX = p.X / control.Bounds.Width;
            double normY = p.Y / control.Bounds.Height;

            await VM.SendMouseMove(normX, normY);
        }

        private async void OnPointerPressed(object sender, PointerPressedEventArgs e)
        {
            var point = e.GetCurrentPoint((Control)sender);

            ((Control)sender).Focus();

            if (point.Properties.PointerUpdateKind == PointerUpdateKind.LeftButtonPressed)
                await VM.SendMouseClick("left_down");

            else if (point.Properties.PointerUpdateKind == PointerUpdateKind.RightButtonPressed)
                await VM.SendMouseClick("right_down");
        }

        private async void OnPointerReleased(object sender, PointerReleasedEventArgs e)
        {
            var point = e.GetCurrentPoint((Control)sender);

            if (point.Properties.PointerUpdateKind == PointerUpdateKind.LeftButtonReleased)
                await VM.SendMouseClick("left_up");

            else if (point.Properties.PointerUpdateKind == PointerUpdateKind.RightButtonReleased)
                await VM.SendMouseClick("right_up");
        }

        private async void OnPointerWheelChanged(object sender, PointerWheelEventArgs e)
        {
            await VM.SendMouseWheel((int)(e.Delta.Y * 120));
        }

        // 🔥 КЛАВИАТУРА
        private async void OnKeyDown(object? sender, KeyEventArgs e)
        {
            if (VM == null)
                return;

            switch (e.Key)
            {
                case Key.Enter:
                case Key.Back:
                case Key.Delete:
                case Key.Left:
                case Key.Right:
                case Key.Up:
                case Key.Down:
                case Key.Tab:
                case Key.LeftCtrl:
                case Key.RightCtrl:
                case Key.LeftAlt:
                case Key.RightAlt:
                case Key.LeftShift:
                case Key.RightShift:

                    await VM.SendKey(e, true);
                    break;
            }
        }

        private async void OnKeyUp(object? sender, KeyEventArgs e)
        {
            if (VM == null)
                return;

            switch (e.Key)
            {
                case Key.Enter:
                case Key.Back:
                case Key.Delete:
                case Key.Left:
                case Key.Right:
                case Key.Up:
                case Key.Down:
                case Key.Tab:
                case Key.LeftCtrl:
                case Key.RightCtrl:
                case Key.LeftAlt:
                case Key.RightAlt:
                case Key.LeftShift:
                case Key.RightShift:

                    await VM.SendKey(e, true);
                    break;
            }
        }

        private async void OnTextInput(object? sender, TextInputEventArgs e)
        {
            if (VM != null && !string.IsNullOrEmpty(e.Text))
                await VM.SendText(e.Text);
        }
    }
}