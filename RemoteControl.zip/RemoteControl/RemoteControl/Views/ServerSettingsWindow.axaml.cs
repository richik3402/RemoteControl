using Avalonia.Controls;
using RemoteControl.ViewModels;

namespace RemoteControl
{
    public partial class ServerSettingsWindow : Window
    {
        public ServerSettingsWindow()
        {
            InitializeComponent();

            var vm = new ServerSettingsViewModel();
            vm.CloseAction = Close;

            DataContext = vm;
        }
    }
}