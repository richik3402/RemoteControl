using Avalonia;
using Avalonia.Controls;
using Avalonia.Markup.Xaml;

namespace RemoteControl;

public partial class ClientSettingsWindow : Window
{
    public ClientSettingsWindow()
    {
        InitializeComponent();
    }
}