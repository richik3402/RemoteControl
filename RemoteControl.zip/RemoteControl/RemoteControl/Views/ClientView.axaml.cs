using Avalonia.Controls;

namespace RemoteControl.Views
{
    public partial class ClientView : UserControl
    {
        public ClientView()
        {
            InitializeComponent();
        }
    }
}